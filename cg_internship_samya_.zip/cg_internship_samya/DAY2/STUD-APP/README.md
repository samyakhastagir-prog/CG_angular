# # StudentApp

This project was generated using Angular CLI version 21.2.13.

## Project Overview

This project was developed as part of the Angular Heritage Internship assignment.

### Tasks Performed

1. Added and displayed student information on the webpage by modifying:

   * `./src/app/app.html`
   * `./src/app/app.ts`

2. Installed the required npm packages and project dependencies.

3. Executed the application locally using the Angular development server (`ng serve`).

4. Implemented solutions for the assignment questions provided.

## Assignment Solution Files

The implemented solutions can be found in:

* `./src/app/app.html`
* `./src/app/app.ts`

## Assignment Questions

The assignment questions are available in:

* `./homeworkQuestions.txt`

## How to Run the Project

```bash
npm install
ng serve
```

After running the above commands, open your browser and navigate to:

`http://localhost:4200/`
