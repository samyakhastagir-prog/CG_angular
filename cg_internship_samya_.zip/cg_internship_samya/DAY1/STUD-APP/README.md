```markdown
# StudentApp

An Angular application developed as part of the Angular Heritage Internship Day 02 assignment. This project demonstrates basic Angular concepts, component modification, data display, and assignment-based implementation.

---

## Project Objectives

The goal of this assignment was to:

* Understand the Angular project structure.
* Modify component files.
* Display custom student information on the webpage.
* Practice TypeScript and Angular template development.
* Run and test the application using Angular CLI.

---

## Work Completed

### 1. Updated Application Content

Modified the following files to display custom student information and implement assignment requirements:

```text
src/app/app.html
src/app/app.ts
```

### 2. Installed Project Dependencies

```bash
npm install
```

Installed all required npm packages specified in the project's `package.json`.

### 3. Ran the Development Server

```bash
ng serve
```

The application was successfully compiled and served locally through Angular's development server.

### 4. Implemented Assignment Solutions

All assignment questions were solved and marked with comments inside the relevant files for easy identification.

---

## Assignment Files

Solutions can be found in:

```text
src/app/app.html
src/app/app.ts
```

Assignment questions are available in:

```text
homeworkQuestions.txt
```

---

## Project Structure

```text
student-app/
├── src/
│   ├── app/
│   │   ├── app.html
│   │   ├── app.ts
│   │   └── app.css
│   ├── main.ts
│   └── styles.css
├── public/
├── angular.json
├── package.json
├── tsconfig.json
├── README.md
└── homeworkQuestions.txt
```

---

## Running the Project

Install dependencies:

```bash
npm install
```

Start the development server:

```bash
ng serve
```

Open the application in your browser:

```text
http://localhost:4200
```

---

## Learning Outcomes

Through this assignment, I learned:

* Angular project structure and file organization.
* Editing Angular component templates and TypeScript files.
* Installing and managing npm packages.
* Running and testing Angular applications locally.
* Implementing assignment requirements using Angular.
